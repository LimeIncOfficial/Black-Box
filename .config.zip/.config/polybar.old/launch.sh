#!/bin/bash


killall -q polybar
polybar example
