/* i3blocks-config.h.  Generated from i3blocks-config.h.in by configure.  */
/* i3blocks-config.h.in.  Generated from configure.ac by autoheader.  */

/* Name of package */
#define PACKAGE "i3blocks"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define PACKAGE_NAME "i3blocks"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "i3blocks 1.5"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "i3blocks"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.5"

/* Version number of package */
#define VERSION "1.5"
