<!-- If this is a request for another formatter, give an example of the command needed to run it. -->
<!-- Delete non-relevant parts if this is not a bug report. -->

##### fmt version: #####
<!-- Can be found with the `plugin list` command. -->


##### Expected behavior: #####


##### Actual behavior: #####
